#include<iostream>
#include<queue>
using namespace std;
int main()
{
int m,n;
cin >> n;
cin >> m;
int cost[n+1][n+1],i,j,k,v,visit[n+1];
int a[n][n];
for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            a[i][j]=0;
            cost[i+1][j+1]=0;
        }
	}
	for(int i=0;i<m;i++){
            int x,y;
            cin>>x>>y;
            a[x-1][y-1]=1;
            a[y-1][x-1]=1;
	}
	for(int i=0;i<n;i++) a[i][i]=1;
	cin>>v;
	for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(a[i][j]==0){
                cost[i+1][j+1]=1;
            }
        }
	}
int level[n+1];
for(int i=1;i<=n;i++) level[i]=0;
    queue<int> q;
    q.push(v);
    visit[v]=1;
    int count=-1;
    while(!q.empty()){
            v=q.front();
            count+=1;
       for(k=1;k<=n;k++){
           if(cost[v][k]==1&&visit[k]!=1){
              q.push(k);
              visit[k]=1;
              level[k]=level[v]+1;
       }}
       q.pop();
}
for(int i=1;i<=n;i++)
{
    if(level[i]!=0)
    cout<<level[i]<<" ";
}}
